/* =========================================================
   HOKM ONLINE - APP CONTROLLER
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.main = {
  async init() {
    this.bind();
    if (HOKM.supabase) await HOKM.auth.init();
    this.refresh();
  },

  bind() {
    document.addEventListener("click", e => {
      const nav = e.target.closest("[data-nav]");
      if (nav) {
        HOKM.ui.showScreen(nav.dataset.nav);
        if (nav.dataset.nav === "shop-screen") HOKM.shop.render();
        if (nav.dataset.nav === "leaderboard-screen") HOKM.leaderboard.render();
        if (nav.dataset.nav === "profile-screen") HOKM.profile.render();
      }
    });

    document.querySelector("#login-form")?.addEventListener("submit", async e => {
      e.preventDefault();
      try {
        await HOKM.auth.signIn(e.target.email.value, e.target.password.value);
        HOKM.ui.toast("ورود موفق بود.", "success");
        HOKM.ui.showScreen("home-screen");
      } catch (err) { HOKM.ui.toast(err.message, "error"); }
    });

    document.querySelector("#signup-form")?.addEventListener("submit", async e => {
      e.preventDefault();
      try {
        await HOKM.auth.signUp(e.target.email.value, e.target.password.value, e.target.username.value);
        HOKM.ui.toast("حساب ساخته شد. اگر تأیید ایمیل فعال باشد، ایمیل را تأیید کنید.", "success");
      } catch (err) { HOKM.ui.toast(err.message, "error"); }
    });

    document.querySelector("#logout-btn")?.addEventListener("click", () => HOKM.auth.signOut());
    document.querySelector("#create-room-btn")?.addEventListener("click", async () => {
      try {
        const room = await HOKM.room.create();
        document.querySelector("#room-code").textContent = room.code;
        HOKM.ui.showScreen("room-screen");
        await this.renderRoom();
      } catch(e) { HOKM.ui.toast(e.message, "error"); }
    });

    document.querySelector("#join-room-btn")?.addEventListener("click", async () => {
      try {
        const room = await HOKM.room.find(document.querySelector("#join-code").value);
        await HOKM.room.join(room.id);
        await HOKM.room.subscribe(room.id);
        document.querySelector("#room-code").textContent = room.code;
        HOKM.ui.showScreen("room-screen");
        await this.renderRoom();
      } catch(e) { HOKM.ui.toast(e.message, "error"); }
    });

    document.querySelector("#ready-btn")?.addEventListener("click", async () => {
      try { await HOKM.room.ready(true); await this.renderRoom(); }
      catch(e) { HOKM.ui.toast(e.message, "error"); }
    });

    document.querySelector("#start-local-btn")?.addEventListener("click", () => {
      HOKM.game.start();
      HOKM.game.state.mySeat = 0;
      HOKM.ui.showScreen("game-screen");
      HOKM.gameUI.render();
    });
  },

  refresh() {
    const logged = HOKM.auth.isLoggedIn();
    document.querySelectorAll("[data-auth-only]").forEach(x => x.hidden = !logged);
    document.querySelectorAll("[data-guest-only]").forEach(x => x.hidden = logged);
    HOKM.wallet.render();
    HOKM.profile.render();
  },

  async renderRoom() {
    const box = document.querySelector("#room-players");
    if (!box || !HOKM.room.current) return;
    try {
      const players = await HOKM.room.players();
      box.innerHTML = [0,1,2,3].map(seat => {
        const p = players.find(x => x.seat === seat);
        return `<div class="seat">
          <span>${seat+1}</span>
          <strong>${HOKM.ui.escape(p?.profiles?.username || "خالی")}</strong>
          <small>${p ? (p.is_ready ? "آماده ✓" : "منتظر") : "صندلی خالی"}</small>
        </div>`;
      }).join("");
    } catch(e) { HOKM.ui.toast(e.message, "error"); }
  }
};

document.addEventListener("DOMContentLoaded", () => HOKM.main.init());
