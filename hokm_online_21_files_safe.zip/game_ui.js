/* =========================================================
   HOKM ONLINE - GAME UI
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.gameUI = {
  render() {
    const board = document.querySelector("#game-board");
    if (!board || !HOKM.game.state) return;
    const s = HOKM.game.state;
    const me = HOKM.game.state.mySeat ?? 0;

    board.innerHTML = `
      <div class="game-status">
        <span>حکم: ${s.trump ? this.suitName(s.trump) : "انتخاب نشده"}</span>
        <span>تریک: ${s.trickNumber + 1}/13</span>
        <span>نوبت: بازیکن ${s.turn + 1}</span>
      </div>
      <div class="table-board">
        <div class="opponent top">بازیکن ${((me+2)%4)+1}</div>
        <div class="opponent left">بازیکن ${((me+1)%4)+1}</div>
        <div class="opponent right">بازیکن ${((me+3)%4)+1}</div>
        <div class="trick-center">${s.trick.map(x => `<div class="played-card">${this.cardText(x.card)}</div>`).join("")}</div>
        <div class="hand bottom">${s.hands[me].map(c =>
          `<button class="playing-card" data-card="${c.id}">${this.cardText(c)}</button>`).join("")}</div>
      </div>`;

    board.querySelectorAll("[data-card]").forEach(btn => {
      btn.onclick = () => {
        try {
          HOKM.game.play(me, btn.dataset.card);
          this.render();
        } catch (e) { HOKM.ui.toast(e.message, "error"); }
      };
    });
  },

  suitName(s) {
    return { hearts:"♥ دل", diamonds:"♦ خشت", clubs:"♣ گشنیز", spades:"♠ پیک" }[s] || s;
  },

  cardText(c) {
    const ranks = {11:"J",12:"Q",13:"K",14:"A"};
    const suit = {hearts:"♥",diamonds:"♦",clubs:"♣",spades:"♠"}[c.suit];
    return `${ranks[c.rank] || c.rank}${suit}`;
  }
};
