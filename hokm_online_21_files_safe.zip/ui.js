/* =========================================================
   HOKM ONLINE - UI UTILITIES
========================================================= */
window.HOKM = window.HOKM || {};

HOKM.ui = {
  $(selector, root = document) {
    return root.querySelector(selector);
  },

  $$(selector, root = document) {
    return [...root.querySelectorAll(selector)];
  },

  escape(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  },

  toast(message, type = "info") {
    let box = document.querySelector("#toast-container");
    if (!box) {
      box = document.createElement("div");
      box.id = "toast-container";
      box.className = "toast-container";
      document.body.appendChild(box);
    }
    const el = document.createElement("div");
    el.className = `toast toast-${type}`;
    el.textContent = message;
    box.appendChild(el);
    setTimeout(() => el.remove(), 3200);
  },

  setLoading(button, loading, text = "در حال انجام...") {
    if (!button) return;
    if (loading) {
      button.dataset.oldText = button.textContent;
      button.disabled = true;
      button.textContent = text;
    } else {
      button.disabled = false;
      button.textContent = button.dataset.oldText || button.textContent;
    }
  },

  showScreen(id) {
    this.$$("[data-screen]").forEach(x => x.classList.remove("active"));
    const screen = document.getElementById(id);
    if (screen) screen.classList.add("active");
  },

  modal(title, body, actions = []) {
    const old = document.querySelector(".app-modal");
    if (old) old.remove();

    const modal = document.createElement("div");
    modal.className = "app-modal";
    modal.innerHTML = `
      <div class="modal-card" role="dialog" aria-modal="true">
        <button class="modal-close" aria-label="بستن">×</button>
        <h3>${this.escape(title)}</h3>
        <div class="modal-body">${body}</div>
        <div class="modal-actions">
          ${actions.map((a, i) => `<button class="btn ${a.className || ""}" data-action="${i}">${this.escape(a.label)}</button>`).join("")}
        </div>
      </div>`;
    document.body.appendChild(modal);

    const close = () => modal.remove();
    modal.querySelector(".modal-close").onclick = close;
    modal.addEventListener("click", e => {
      if (e.target === modal) close();
      const btn = e.target.closest("[data-action]");
      if (btn) actions[Number(btn.dataset.action)]?.run?.(close);
    });
    return { close, modal };
  }
};
