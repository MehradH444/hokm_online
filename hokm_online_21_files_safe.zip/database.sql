-- =========================================================
-- HOKM ONLINE - SAFE FREE-TO-PLAY DATABASE
-- بدون خرید سکه، شرط‌بندی، جایزه نقدی یا پرداخت برای ورود.
-- سکه‌ها فقط ارز مجازی داخل بازی هستند.
-- =========================================================

create extension if not exists pgcrypto;

create table if not exists public.profiles(
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null check(char_length(username) between 2 and 20),
  avatar_url text,
  level integer not null default 1 check(level >= 1),
  coins bigint not null default 3000 check(coins >= 0),
  games_played integer not null default 0 check(games_played >= 0),
  games_won integer not null default 0 check(games_won >= 0 and games_won <= games_played),
  total_tricks integer not null default 0 check(total_tricks >= 0),
  experience bigint not null default 0 check(experience >= 0),
  is_online boolean not null default false,
  last_seen timestamptz default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.player_settings(
  user_id uuid primary key references public.profiles(id) on delete cascade,
  sound_enabled boolean not null default true,
  music_enabled boolean not null default true,
  notifications_enabled boolean not null default true,
  vibration_enabled boolean not null default true,
  language text not null default 'fa',
  theme text not null default 'dark',
  auto_ready boolean not null default false,
  show_online_status boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists public.shop_items(
  id uuid primary key default gen_random_uuid(),
  item_key text unique not null,
  name text not null,
  description text,
  item_type text not null,
  price bigint not null default 0 check(price >= 0),
  image_url text,
  rarity text not null default 'common',
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.player_inventory(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  item_id uuid not null references public.shop_items(id) on delete cascade,
  purchased_at timestamptz not null default now(),
  is_equipped boolean not null default false,
  unique(user_id,item_id)
);

create table if not exists public.rooms(
  id uuid primary key default gen_random_uuid(),
  code varchar(6) unique not null check(code ~ '^[0-9]{6}$'),
  name text not null default 'اتاق حکم',
  host_id uuid not null references public.profiles(id) on delete cascade,
  entry_fee bigint not null default 0 check(entry_fee=0),
  is_private boolean not null default false,
  status text not null default 'waiting' check(status in('waiting','starting','playing','finished','closed')),
  max_players integer not null default 4 check(max_players=4),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  closed_at timestamptz
);

create table if not exists public.room_players(
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  seat integer not null check(seat between 0 and 3),
  team text not null check(team in('A','B')),
  is_ready boolean not null default false,
  joined_at timestamptz not null default now(),
  left_at timestamptz,
  unique(room_id,user_id),
  unique(room_id,seat)
);

create table if not exists public.games(
  id uuid primary key default gen_random_uuid(),
  room_id uuid references public.rooms(id) on delete set null,
  status text not null default 'waiting' check(status in('waiting','active','finished','cancelled')),
  phase text not null default 'idle',
  trump_suit text,
  lead_suit text,
  current_turn integer check(current_turn between 0 and 3),
  leader_seat integer not null default 0 check(leader_seat between 0 and 3),
  trick_number integer not null default 0 check(trick_number between 0 and 13),
  team_a_tricks integer not null default 0,
  team_b_tricks integer not null default 0,
  team_a_score integer not null default 0,
  team_b_score integer not null default 0,
  winner_team text check(winner_team is null or winner_team in('A','B')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.game_players(
  id uuid primary key default gen_random_uuid(),
  game_id uuid not null references public.games(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  seat integer not null check(seat between 0 and 3),
  team text not null check(team in('A','B')),
  is_host boolean not null default false,
  final_tricks integer not null default 0,
  joined_at timestamptz not null default now(),
  unique(game_id,user_id), unique(game_id,seat)
);

create table if not exists public.game_hands(
  id uuid primary key default gen_random_uuid(),
  game_id uuid not null references public.games(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  card_id text not null,
  suit text not null check(suit in('hearts','diamonds','clubs','spades')),
  rank integer not null check(rank between 2 and 14),
  is_played boolean not null default false,
  received_at timestamptz not null default now(),
  played_at timestamptz,
  unique(game_id,user_id,card_id)
);

create table if not exists public.game_tricks(
  id uuid primary key default gen_random_uuid(),
  game_id uuid not null references public.games(id) on delete cascade,
  trick_number integer not null,
  lead_suit text,
  winner_user_id uuid references public.profiles(id) on delete set null,
  winner_seat integer,
  created_at timestamptz not null default now(),
  finished_at timestamptz,
  unique(game_id,trick_number)
);

create table if not exists public.trick_cards(
  id uuid primary key default gen_random_uuid(),
  trick_id uuid not null references public.game_tricks(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  seat integer not null check(seat between 0 and 3),
  card_id text not null,
  suit text not null check(suit in('hearts','diamonds','clubs','spades')),
  rank integer not null check(rank between 2 and 14),
  play_order integer not null,
  played_at timestamptz not null default now(),
  unique(trick_id,user_id), unique(trick_id,play_order)
);

create table if not exists public.chat_messages(
  id uuid primary key default gen_random_uuid(),
  room_id uuid references public.rooms(id) on delete cascade,
  game_id uuid references public.games(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  message text not null check(char_length(message) between 1 and 100),
  created_at timestamptz not null default now()
);

create table if not exists public.game_history(
  id uuid primary key default gen_random_uuid(),
  game_id uuid not null references public.games(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  team text not null check(team in('A','B')),
  result text not null check(result in('win','loss','draw')),
  tricks integer not null default 0,
  opponent_score integer not null default 0,
  player_score integer not null default 0,
  played_at timestamptz not null default now()
);

create table if not exists public.notifications(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  message text not null,
  notification_type text not null default 'system',
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.friendships(
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete cascade,
  addressee_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check(status in('pending','accepted','rejected','blocked')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check(requester_id <> addressee_id),
  unique(requester_id,addressee_id)
);

create table if not exists public.leaderboard_scores(
  user_id uuid primary key references public.profiles(id) on delete cascade,
  rating integer not null default 1000,
  wins integer not null default 0,
  losses integer not null default 0,
  total_games integer not null default 0,
  win_rate numeric(5,2) not null default 0,
  updated_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at=now(); return new; end; $$;

drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists settings_updated_at on public.player_settings;
create trigger settings_updated_at before update on public.player_settings
for each row execute function public.set_updated_at();

drop trigger if exists rooms_updated_at on public.rooms;
create trigger rooms_updated_at before update on public.rooms
for each row execute function public.set_updated_at();

drop trigger if exists games_updated_at on public.games;
create trigger games_updated_at before update on public.games
for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
declare u text;
begin
  u := left(trim(coalesce(new.raw_user_meta_data->>'username','بازیکن')),20);
  if char_length(u)<2 then u:='بازیکن'; end if;

  insert into public.profiles(id,username) values(new.id,u) on conflict(id) do nothing;
  insert into public.player_settings(user_id) values(new.id) on conflict(user_id) do nothing;
  insert into public.leaderboard_scores(user_id) values(new.id) on conflict(user_id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

insert into public.shop_items(item_key,name,description,item_type,price,rarity,sort_order)
values
('card-classic','کارت کلاسیک','پوسته کلاسیک','card-theme',250,'common',1),
('card-royal','کارت سلطنتی','پوسته ویژه','card-theme',500,'rare',2),
('card-diamond','کارت الماسی','پوسته ویژه','card-theme',900,'epic',3),
('avatar-gold','آواتار طلایی','قاب طلایی','avatar',750,'rare',4),
('table-luxury','میز سلطنتی','تم میز','table-theme',1000,'rare',5),
('emote-fire','ایموت آتش','ایموت چت','emote',200,'common',6)
on conflict(item_key) do nothing;

create or replace function public.purchase_shop_item(p_item_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid; price bigint; bal bigint; newbal bigint; inv uuid;
begin
  uid:=auth.uid(); if uid is null then raise exception 'not_authenticated'; end if;
  select s.price into price from public.shop_items s where s.id=p_item_id and s.is_active;
  if price is null then raise exception 'item_not_found'; end if;
  if exists(select 1 from public.player_inventory where user_id=uid and item_id=p_item_id) then
    raise exception 'item_already_owned';
  end if;
  select coins into bal from public.profiles where id=uid for update;
  if bal < price then raise exception 'insufficient_coins'; end if;
  newbal:=bal-price;
  update public.profiles set coins=newbal where id=uid;
  insert into public.player_inventory(user_id,item_id) values(uid,p_item_id) returning id into inv;
  return jsonb_build_object('success',true,'inventory_id',inv,'balance_after',newbal);
end; $$;

grant execute on function public.purchase_shop_item(uuid) to authenticated;

alter table public.profiles enable row level security;
alter table public.player_settings enable row level security;
alter table public.shop_items enable row level security;
alter table public.player_inventory enable row level security;
alter table public.rooms enable row level security;
alter table public.room_players enable row level security;
alter table public.games enable row level security;
alter table public.game_players enable row level security;
alter table public.game_hands enable row level security;
alter table public.game_tricks enable row level security;
alter table public.trick_cards enable row level security;
alter table public.chat_messages enable row level security;
alter table public.game_history enable row level security;
alter table public.notifications enable row level security;
alter table public.friendships enable row level security;
alter table public.leaderboard_scores enable row level security;

drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated using(true);

drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated using(auth.uid()=id) with check(auth.uid()=id);

drop policy if exists settings_all_own on public.player_settings;
create policy settings_all_own on public.player_settings for all to authenticated
using(auth.uid()=user_id) with check(auth.uid()=user_id);

drop policy if exists shop_read on public.shop_items;
create policy shop_read on public.shop_items for select to anon,authenticated using(is_active);

drop policy if exists inventory_read on public.player_inventory;
create policy inventory_read on public.player_inventory for select to authenticated using(auth.uid()=user_id);

drop policy if exists rooms_read on public.rooms;
create policy rooms_read on public.rooms for select to authenticated using(true);

drop policy if exists rooms_insert on public.rooms;
create policy rooms_insert on public.rooms for insert to authenticated with check(auth.uid()=host_id);

drop policy if exists rooms_update on public.rooms;
create policy rooms_update on public.rooms for update to authenticated using(auth.uid()=host_id) with check(auth.uid()=host_id);

drop policy if exists room_players_read on public.room_players;
create policy room_players_read on public.room_players for select to authenticated using(true);

drop policy if exists room_players_insert on public.room_players;
create policy room_players_insert on public.room_players for insert to authenticated with check(auth.uid()=user_id);

drop policy if exists room_players_update on public.room_players;
create policy room_players_update on public.room_players for update to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);

drop policy if exists games_read on public.games;
create policy games_read on public.games for select to authenticated using(true);

drop policy if exists game_players_read on public.game_players;
create policy game_players_read on public.game_players for select to authenticated using(true);

drop policy if exists game_hands_read_own on public.game_hands;
create policy game_hands_read_own on public.game_hands for select to authenticated using(auth.uid()=user_id);

drop policy if exists tricks_read on public.game_tricks;
create policy tricks_read on public.game_tricks for select to authenticated using(true);

drop policy if exists trick_cards_read on public.trick_cards;
create policy trick_cards_read on public.trick_cards for select to authenticated using(true);

drop policy if exists chat_read on public.chat_messages;
create policy chat_read on public.chat_messages for select to authenticated using(true);

drop policy if exists chat_insert on public.chat_messages;
create policy chat_insert on public.chat_messages for insert to authenticated with check(auth.uid()=user_id);

drop policy if exists history_read on public.game_history;
create policy history_read on public.game_history for select to authenticated using(auth.uid()=user_id);

drop policy if exists notifications_read on public.notifications;
create policy notifications_read on public.notifications for select to authenticated using(auth.uid()=user_id);

drop policy if exists notifications_update on public.notifications;
create policy notifications_update on public.notifications for update to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);

drop policy if exists friendships_read on public.friendships;
create policy friendships_read on public.friendships for select to authenticated
using(auth.uid()=requester_id or auth.uid()=addressee_id);

drop policy if exists friendships_insert on public.friendships;
create policy friendships_insert on public.friendships for insert to authenticated with check(auth.uid()=requester_id);

drop policy if exists leaderboard_read on public.leaderboard_scores;
create policy leaderboard_read on public.leaderboard_scores for select to authenticated using(true);

alter publication supabase_realtime add table public.rooms;
alter publication supabase_realtime add table public.room_players;
alter publication supabase_realtime add table public.games;
alter publication supabase_realtime add table public.game_players;
alter publication supabase_realtime add table public.chat_messages;
