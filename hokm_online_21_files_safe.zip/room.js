/* =========================================================
   HOKM ONLINE - ROOMS
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.room = {
  current: null,
  subscription: null,

  makeCode() {
    return String(Math.floor(100000 + Math.random() * 900000));
  },

  async create(name = "اتاق حکم") {
    if (!HOKM.auth.user) throw new Error("ابتدا وارد شوید.");
    const code = this.makeCode();
    const { data, error } = await HOKM.supabase.from("rooms")
      .insert({
        code, name, host_id: HOKM.auth.user.id,
        entry_fee: 0, is_private: false, status: "waiting"
      }).select().single();
    if (error) throw error;
    await this.join(data.id, 0, "A");
    this.current = data;
    await this.subscribe(data.id);
    return data;
  },

  async find(code) {
    const { data, error } = await HOKM.supabase.from("rooms")
      .select("*").eq("code", String(code).trim()).maybeSingle();
    if (error) throw error;
    if (!data) throw new Error("اتاق پیدا نشد.");
    return data;
  },

  async join(roomId, seat = null, team = null) {
    const room = await HOKM.supabase.from("room_players")
      .select("seat").eq("room_id", roomId).order("seat");
    if (room.error) throw room.error;
    const used = new Set((room.data || []).map(x => x.seat));
    if (seat === null) {
      seat = [0,1,2,3].find(x => !used.has(x));
      if (seat === undefined) throw new Error("اتاق پر است.");
    }
    team = team || (seat % 2 === 0 ? "A" : "B");
    const { data, error } = await HOKM.supabase.from("room_players")
      .insert({ room_id: roomId, user_id: HOKM.auth.user.id, seat, team })
      .select().single();
    if (error) throw error;
    this.current = await this.findById(roomId);
    return data;
  },

  async findById(id) {
    const { data, error } = await HOKM.supabase.from("rooms").select("*").eq("id", id).single();
    if (error) throw error;
    return data;
  },

  async players(roomId = this.current?.id) {
    if (!roomId) return [];
    const { data, error } = await HOKM.supabase.from("room_players")
      .select("*, profiles(username, avatar_url)")
      .eq("room_id", roomId).order("seat");
    if (error) throw error;
    return data || [];
  },

  async ready(value = true) {
    if (!this.current) throw new Error("اتاقی انتخاب نشده.");
    const { error } = await HOKM.supabase.from("room_players")
      .update({ is_ready: value }).eq("room_id", this.current.id).eq("user_id", HOKM.auth.user.id);
    if (error) throw error;
  },

  async subscribe(roomId) {
    if (this.subscription) await HOKM.supabase.removeChannel(this.subscription);
    this.subscription = HOKM.supabase.channel(`room:${roomId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "room_players", filter: `room_id=eq.${roomId}` },
        () => HOKM.main?.renderRoom?.())
      .on("postgres_changes", { event: "*", schema: "public", table: "rooms", filter: `id=eq.${roomId}` },
        () => HOKM.main?.renderRoom?.())
      .subscribe();
    return this.subscription;
  }
};
