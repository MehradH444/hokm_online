/* =========================================================
   HOKM ONLINE - FRIENDS
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.friends = {
  async list() {
    const id = HOKM.auth.user?.id;
    if (!id) return [];
    const { data, error } = await HOKM.supabase.from("friendships")
      .select("*, requester:requester_id(username), addressee:addressee_id(username)")
      .or(`requester_id.eq.${id},addressee_id.eq.${id}`).order("created_at", { ascending:false });
    if (error) throw error;
    return data || [];
  },

  async request(addresseeId) {
    if (!HOKM.auth.user) throw new Error("ابتدا وارد شوید.");
    if (addresseeId === HOKM.auth.user.id) throw new Error("نمی‌توانید خودتان را اضافه کنید.");
    const { error } = await HOKM.supabase.from("friendships").insert({
      requester_id: HOKM.auth.user.id, addressee_id: addresseeId, status:"pending"
    });
    if (error) throw error;
  },

  async respond(id, status) {
    if (!["accepted","rejected","blocked"].includes(status)) throw new Error("وضعیت نامعتبر.");
    const { error } = await HOKM.supabase.from("friendships").update({ status }).eq("id", id);
    if (error) throw error;
  }
};
