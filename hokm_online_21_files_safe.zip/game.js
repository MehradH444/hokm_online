/* =========================================================
   HOKM ONLINE - COMPLETE LOCAL GAME ENGINE
   قوانین اصلی: چهار بازیکن، دو تیم، ۵۲ کارت، حکم، پیروی از خال،
   تریک، امتیاز و وضعیت نوبت.
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.game = {
  state: null,

  suits: ["hearts","diamonds","clubs","spades"],
  ranks: [2,3,4,5,6,7,8,9,10,11,12,13,14],

  createDeck() {
    return this.suits.flatMap(s => this.ranks.map(r => ({ id: `${s}-${r}`, suit: s, rank: r })));
  },

  shuffle(deck) {
    const a = [...deck];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  },

  start({ dealer = 0 } = {}) {
    const deck = this.shuffle(this.createDeck());
    const hands = [[],[],[],[]];
    deck.forEach((card, i) => hands[i % 4].push(card));
    this.state = {
      phase: "trump-selection",
      trump: null,
      leadSuit: null,
      turn: (dealer + 1) % 4,
      leader: (dealer + 1) % 4,
      hands,
      trick: [],
      trickNumber: 0,
      teamTricks: { A: 0, B: 0 },
      teamScores: { A: 0, B: 0 },
      winner: null
    };
    return this.state;
  },

  team(seat) { return seat % 2 === 0 ? "A" : "B"; },

  legalCards(seat) {
    const s = this.state;
    if (!s) return [];
    const hand = s.hands[seat] || [];
    if (!s.leadSuit) return hand;
    const same = hand.filter(c => c.suit === s.leadSuit);
    return same.length ? same : hand;
  },

  chooseTrump(seat, suit) {
    const s = this.state;
    if (!s || s.phase !== "trump-selection") throw new Error("انتخاب حکم ممکن نیست.");
    if (seat !== s.turn) throw new Error("نوبت شما نیست.");
    if (!this.suits.includes(suit)) throw new Error("خال نامعتبر.");
    s.trump = suit;
    s.phase = "playing";
    s.leadSuit = null;
    s.turn = s.leader;
    return s;
  },

  play(seat, cardId) {
    const s = this.state;
    if (!s || s.phase !== "playing") throw new Error("بازی در وضعیت مناسب نیست.");
    if (seat !== s.turn) throw new Error("نوبت شما نیست.");
    const legal = this.legalCards(seat);
    const card = legal.find(c => c.id === cardId);
    if (!card) throw new Error("این کارت در این نوبت مجاز نیست.");

    const idx = s.hands[seat].findIndex(c => c.id === cardId);
    s.hands[seat].splice(idx, 1);
    if (!s.leadSuit) s.leadSuit = card.suit;
    s.trick.push({ seat, card });
    s.turn = (seat + 1) % 4;

    if (s.trick.length === 4) this.finishTrick();
    return s;
  },

  strength(card) {
    const s = this.state;
    const trump = card.suit === s.trump;
    const lead = card.suit === s.leadSuit;
    return (trump ? 200 : lead ? 100 : 0) + card.rank;
  },

  finishTrick() {
    const s = this.state;
    const winner = s.trick.reduce((best, x) =>
      this.strength(x.card) > this.strength(best.card) ? x : best
    );
    s.teamTricks[this.team(winner.seat)]++;
    s.trickNumber++;
    s.trick = [];
    s.leadSuit = null;
    s.leader = winner.seat;
    s.turn = winner.seat;

    if (s.trickNumber >= 13) {
      s.phase = "game-finished";
      s.winner = s.teamTricks.A > s.teamTricks.B ? "A" : s.teamTricks.B > s.teamTricks.A ? "B" : null;
      s.teamScores.A += s.teamTricks.A;
      s.teamScores.B += s.teamTricks.B;
    }
    return s;
  }
};
