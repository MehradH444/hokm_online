/* =========================================================
   HOKM ONLINE - AUTH
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.auth = {
  user: null,
  profile: null,

  async init() {
    if (!HOKM.supabase) return;
    const { data } = await HOKM.supabase.auth.getSession();
    this.user = data?.session?.user || null;
    if (this.user) await this.loadProfile();

    HOKM.supabase.auth.onAuthStateChange(async (_event, session) => {
      this.user = session?.user || null;
      if (this.user) await this.loadProfile();
      else this.profile = null;
      HOKM.main?.refresh?.();
    });
  },

  async signUp(email, password, username) {
    if (!HOKM.supabase) throw new Error("Supabase هنوز تنظیم نشده است.");
    const { data, error } = await HOKM.supabase.auth.signUp({
      email, password,
      options: { data: { username } }
    });
    if (error) throw error;
    this.user = data.user;
    return data;
  },

  async signIn(email, password) {
    if (!HOKM.supabase) throw new Error("Supabase هنوز تنظیم نشده است.");
    const { data, error } = await HOKM.supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    this.user = data.user;
    await this.loadProfile();
    return data;
  },

  async signOut() {
    if (HOKM.supabase) await HOKM.supabase.auth.signOut();
    this.user = null;
    this.profile = null;
    HOKM.main?.refresh?.();
  },

  async loadProfile() {
    if (!this.user || !HOKM.supabase) return null;
    const { data, error } = await HOKM.supabase
      .from("profiles")
      .select("*")
      .eq("id", this.user.id)
      .maybeSingle();
    if (error) throw error;
    this.profile = data;
    return data;
  },

  isLoggedIn() {
    return !!this.user;
  }
};
