/* =========================================================
   HOKM ONLINE - COSMETIC SHOP
   خرید آیتم فقط با سکه رایگان داخل بازی.
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.shop = {
  async items() {
    if (!HOKM.supabase) return [];
    const { data, error } = await HOKM.supabase
      .from("shop_items").select("*").eq("is_active", true).order("sort_order");
    if (error) throw error;
    return data || [];
  },

  async inventory() {
    if (!HOKM.auth.user || !HOKM.supabase) return [];
    const { data, error } = await HOKM.supabase
      .from("player_inventory").select("*, shop_items(*)").eq("user_id", HOKM.auth.user.id);
    if (error) throw error;
    return data || [];
  },

  async buy(itemId) {
    if (!HOKM.auth.isLoggedIn()) throw new Error("ابتدا وارد شوید.");
    const { data, error } = await HOKM.supabase.rpc("purchase_shop_item", { p_item_id: itemId });
    if (error) throw error;
    await HOKM.wallet.refresh();
    return data;
  },

  async render() {
    const box = document.querySelector("#shop-content");
    if (!box) return;
    try {
      const items = await this.items();
      box.innerHTML = items.map(item => `
        <article class="shop-card">
          <div class="shop-icon">${item.item_type === "avatar" ? "👤" : item.item_type === "emote" ? "🔥" : "🃏"}</div>
          <h3>${HOKM.ui.escape(item.name)}</h3>
          <p>${HOKM.ui.escape(item.description || "")}</p>
          <strong>${Number(item.price).toLocaleString("fa-IR")} سکه</strong>
          <button class="btn" data-buy="${item.id}">خرید با سکه رایگان</button>
        </article>`).join("") || `<div class="empty">فروشگاه خالی است.</div>`;
      box.querySelectorAll("[data-buy]").forEach(btn => {
        btn.onclick = async () => {
          try {
            await this.buy(btn.dataset.buy);
            HOKM.ui.toast("آیتم با موفقیت خریداری شد.", "success");
            await this.render();
          } catch (e) { HOKM.ui.toast(e.message, "error"); }
        };
      });
    } catch (e) {
      box.innerHTML = `<div class="empty">خطا: ${HOKM.ui.escape(e.message)}</div>`;
    }
  }
};
