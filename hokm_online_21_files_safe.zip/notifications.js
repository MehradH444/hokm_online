/* =========================================================
   HOKM ONLINE - NOTIFICATIONS
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.notifications = {
  async list() {
    if (!HOKM.auth.user) return [];
    const { data, error } = await HOKM.supabase.from("notifications")
      .select("*").eq("user_id", HOKM.auth.user.id).order("created_at", { ascending:false }).limit(50);
    if (error) throw error;
    return data || [];
  },

  async markRead(id) {
    const { error } = await HOKM.supabase.from("notifications")
      .update({ is_read:true }).eq("id", id).eq("user_id", HOKM.auth.user.id);
    if (error) throw error;
  }
};
