/* =========================================================
   HOKM ONLINE - PROFILE
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.profile = {
  async get(userId = HOKM.auth.user?.id) {
    if (!userId || !HOKM.supabase) return null;
    const { data, error } = await HOKM.supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
    if (error) throw error;
    return data;
  },

  async updateUsername(username) {
    username = String(username || "").trim();
    if (username.length < 2 || username.length > 20) throw new Error("نام باید بین ۲ تا ۲۰ کاراکتر باشد.");
    const { data, error } = await HOKM.supabase
      .from("profiles").update({ username }).eq("id", HOKM.auth.user.id).select().single();
    if (error) throw error;
    HOKM.auth.profile = data;
    HOKM.main.refresh();
    return data;
  },

  render(profile = HOKM.auth.profile) {
    const box = document.querySelector("#profile-content");
    if (!box) return;
    if (!profile) {
      box.innerHTML = `<div class="empty">برای دیدن پروفایل وارد شوید.</div>`;
      return;
    }
    box.innerHTML = `
      <div class="profile-hero">
        <div class="avatar">${HOKM.ui.escape((profile.username || "ب").slice(0,1))}</div>
        <div>
          <h2>${HOKM.ui.escape(profile.username)}</h2>
          <p>سطح ${profile.level} · ${profile.experience} XP</p>
        </div>
      </div>
      <div class="stats-grid">
        <div><b>${profile.games_played}</b><span>بازی</span></div>
        <div><b>${profile.games_won}</b><span>برد</span></div>
        <div><b>${profile.total_tricks}</b><span>تریک</span></div>
        <div><b>${profile.coins}</b><span>سکه رایگان</span></div>
      </div>`;
  }
};
