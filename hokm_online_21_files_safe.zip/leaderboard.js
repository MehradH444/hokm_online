/* =========================================================
   HOKM ONLINE - LEADERBOARD
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.leaderboard = {
  async top(limit = 50) {
    const { data, error } = await HOKM.supabase.from("leaderboard_scores")
      .select("*, profiles(username, avatar_url)")
      .order("rating", { ascending:false }).limit(limit);
    if (error) throw error;
    return data || [];
  },

  async render() {
    const box = document.querySelector("#leaderboard-content");
    if (!box) return;
    try {
      const rows = await this.top();
      box.innerHTML = rows.map((r,i) => `
        <div class="leader-row">
          <b>#${i+1}</b>
          <span>${HOKM.ui.escape(r.profiles?.username || "بازیکن")}</span>
          <strong>${r.rating}</strong>
          <small>${r.wins} برد · ${r.losses} باخت</small>
        </div>`).join("") || `<div class="empty">هنوز رتبه‌ای ثبت نشده است.</div>`;
    } catch (e) {
      box.innerHTML = `<div class="empty">${HOKM.ui.escape(e.message)}</div>`;
    }
  }
};
