/* =========================================================
   HOKM ONLINE - CHAT
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.chat = {
  channel: null,

  async load(roomId) {
    if (!HOKM.supabase) return [];
    const { data, error } = await HOKM.supabase
      .from("chat_messages").select("*, profiles(username)")
      .eq("room_id", roomId).order("created_at", { ascending: true }).limit(100);
    if (error) throw error;
    return data || [];
  },

  async send(roomId, message) {
    message = String(message || "").trim();
    if (!message || message.length > 100) throw new Error("پیام باید بین ۱ تا ۱۰۰ کاراکتر باشد.");
    const { data, error } = await HOKM.supabase.from("chat_messages").insert({
      room_id: roomId, user_id: HOKM.auth.user.id, message
    }).select().single();
    if (error) throw error;
    return data;
  },

  async subscribe(roomId, render) {
    if (this.channel) await HOKM.supabase.removeChannel(this.channel);
    this.channel = HOKM.supabase.channel(`chat:${roomId}`)
      .on("postgres_changes", { event:"INSERT", schema:"public", table:"chat_messages", filter:`room_id=eq.${roomId}` }, render)
      .subscribe();
  }
};
