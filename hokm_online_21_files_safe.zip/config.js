/* =========================================================
   HOKM ONLINE - CONFIG
   نسخه رایگان/غیرشرطی
   کلیدهای حساس سرور را هرگز داخل مرورگر قرار ندهید.
========================================================= */
window.HOKM_CONFIG = {
  SUPABASE_URL: "YOUR_SUPABASE_PROJECT_URL",
  SUPABASE_PUBLISHABLE_KEY: "YOUR_SUPABASE_PUBLISHABLE_KEY",
  APP_NAME: "حکم آنلاین",
  STARTING_COINS: 3000,
  MAX_PLAYERS: 4,
  ROOM_CODE_LENGTH: 6,
  DEBUG: true
};
