/* =========================================================
   HOKM ONLINE - REALTIME MULTIPLAYER
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.multiplayer = {
  channel: null,

  async connect(roomId, handlers = {}) {
    if (!HOKM.supabase) throw new Error("Supabase تنظیم نشده است.");
    if (this.channel) await HOKM.supabase.removeChannel(this.channel);

    this.channel = HOKM.supabase.channel(`hokm-game:${roomId}`, {
      config: { broadcast: { self: false }, presence: { key: HOKM.auth.user?.id || crypto.randomUUID() } }
    });

    this.channel
      .on("broadcast", { event: "game-event" }, payload => handlers.event?.(payload.payload))
      .on("presence", { event: "sync" }, () => handlers.presence?.(this.channel.presenceState()))
      .on("presence", { event: "join" }, payload => handlers.join?.(payload))
      .on("presence", { event: "leave" }, payload => handlers.leave?.(payload));

    await this.channel.subscribe(async status => {
      if (status === "SUBSCRIBED") {
        await this.channel.track({
          user_id: HOKM.auth.user?.id,
          username: HOKM.auth.profile?.username,
          online_at: new Date().toISOString()
        });
        handlers.connected?.();
      }
    });
    return this.channel;
  },

  async send(type, data = {}) {
    if (!this.channel) throw new Error("کانال بازی متصل نیست.");
    return this.channel.send({
      type: "broadcast",
      event: "game-event",
      payload: { type, data, userId: HOKM.auth.user?.id, at: Date.now() }
    });
  },

  async disconnect() {
    if (this.channel) await HOKM.supabase.removeChannel(this.channel);
    this.channel = null;
  }
};
