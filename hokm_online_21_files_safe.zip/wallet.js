/* =========================================================
   HOKM ONLINE - FREE COIN WALLET
   سکه‌ها فقط داخل بازی و بدون خرید/شرط‌بندی استفاده می‌شوند.
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.wallet = {
  balance() {
    return Number(HOKM.auth.profile?.coins || 0);
  },

  async refresh() {
    await HOKM.auth.loadProfile();
    this.render();
    return this.balance();
  },

  render() {
    document.querySelectorAll("[data-coins]").forEach(el => {
      el.textContent = this.balance().toLocaleString("fa-IR");
    });
  }
};
