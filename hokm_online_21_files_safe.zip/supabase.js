/* =========================================================
   HOKM ONLINE - SUPABASE CLIENT
========================================================= */
(function () {
  const cfg = window.HOKM_CONFIG || {};
  const ready =
    window.supabase &&
    cfg.SUPABASE_URL &&
    cfg.SUPABASE_PUBLISHABLE_KEY &&
    !cfg.SUPABASE_URL.includes("YOUR_") &&
    !cfg.SUPABASE_PUBLISHABLE_KEY.includes("YOUR_");

  window.HOKM = window.HOKM || {};
  window.HOKM.supabase = ready
    ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_PUBLISHABLE_KEY, {
        auth: {
          autoRefreshToken: true,
          persistSession: true,
          detectSessionInUrl: true
        }
      })
    : null;

  window.HOKM.supabaseReady = ready;
})();
