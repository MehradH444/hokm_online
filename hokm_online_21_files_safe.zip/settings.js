/* =========================================================
   HOKM ONLINE - SETTINGS
========================================================= */
window.HOKM = window.HOKM || {};
HOKM.settings = {
  async get() {
    if (!HOKM.auth.user) return null;
    const { data, error } = await HOKM.supabase.from("player_settings")
      .select("*").eq("user_id", HOKM.auth.user.id).maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(patch) {
    const allowed = ["sound_enabled","music_enabled","notifications_enabled","vibration_enabled",
      "language","theme","auto_ready","show_online_status"];
    const clean = Object.fromEntries(Object.entries(patch).filter(([k]) => allowed.includes(k)));
    const { data, error } = await HOKM.supabase.from("player_settings")
      .upsert({ user_id:HOKM.auth.user.id, ...clean }).select().single();
    if (error) throw error;
    return data;
  }
};
